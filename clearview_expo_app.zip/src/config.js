
export const BACKEND_URL = "https://your-backend-url.onrender.com";
export const GOOGLE_MAPS_API_KEY = "YOUR_GOOGLE_MAPS_API_KEY_HERE";
